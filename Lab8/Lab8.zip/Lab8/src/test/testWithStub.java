package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class testWithStub {

	@Test
	void testUniversal_convert() {
		UniversalStub stub = new UniversalStub();
		double expectedResult = 1000.0;
		assertEquals(expectedResult, stub.convert(1, "Distance", "kilometer", "meter"));
	}
	
	@Test
	void testDistance_convert() {
		DistanceStub stub = new DistanceStub();
		double expectedResult = 1000.0;
		assertEquals(expectedResult, stub.convert(1, "kilometer", "meter"));
	}
	
	@Test
	void testDistance_getMultiplier() {
		DistanceStub stub = new DistanceStub();
		double expectedResult = 1000.0;
		assertEquals(expectedResult, stub.getMultiplier("kilometer", "meter"));
	}
	
	@Test
	void testTemperature_convert() {
		TemperatureStub stub = new TemperatureStub();
		double expectedResult = 310.15;
		assertEquals(expectedResult, stub.convert(37, "C", "K"));
	}
	
	@Test
	void testWeight_convert() {
		WeightStub stub = new WeightStub();
		double expectedResult = 1000.0;
		assertEquals(expectedResult, stub.convert(1, "kilometer", "meter"));
	}
	
	@Test
	void testWeight_getMultiplier() {
		WeightStub stub = new WeightStub();
		double expectedResult = 1000.0;
		assertEquals(expectedResult, stub.getMultiplier("kilogram", "gram"));
	}
}
package test;

import main.UniversalConverter;

/*
 * A driver for testing the UniveralConverter class
 * 
 * @author Asst.Prof.Chitsutha Soomlek, College of Computing, KKU
 * @version 1.0
 */

public class Driver {

	/*
	 * The entry point to the UniversalConverter class
	 * 
	 * @parameter args = command-line arguments
	 */

	public static void main(String[] args) {
		
		double originalValue;
		double convertedValue;
		String selectedChoice;
		String from;
		String to;
		
		UniversalStub universalstub = new UniversalStub();
		DistanceStub distancestub = new DistanceStub();
		TemperatureStub temperaturestub = new TemperatureStub();
		WeightStub weightstub = new WeightStub();
		
		// results of the universal converter
			originalValue = 20.0;
			convertedValue = 0.0;
			selectedChoice = "Distance";
			from = "kilometer";
			to = "meter";
	
			convertedValue = universalstub.convert(originalValue, selectedChoice, from, to);
			System.out.println("\nUniversal Distance Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);

		// results of the universal converter
			originalValue = 20.0;
			convertedValue = 0.0;
			selectedChoice = "Temperature";
			from = "C";
			to = "K";
	
			convertedValue = universalstub.convert(originalValue, selectedChoice, from, to);
			System.out.println("\nUniversal Temperature Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);

		// results of the universal converter
			originalValue = 20.0;
			convertedValue = 0.0;
			selectedChoice = "Weight";
			from = "kilogram";
			to = "gram";
	
			convertedValue = universalstub.convert(originalValue, selectedChoice, from, to);
			System.out.println("\nUniversal Weight Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);

		// results of the Distance converter
			double MultiplierDistance = 0.0;
			originalValue = 10.0;
			convertedValue = 0.0;
			from = "kilometer";
			to = "meter";
	
			convertedValue = distancestub.convert(originalValue, from, to);
			MultiplierDistance = distancestub.getMultiplier(from, to);
			System.out.println("\nDistance Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
			System.out.println("Multiplier = " + MultiplierDistance + "\n");

		// results of the Temperature converter
			originalValue = 10.0;
			convertedValue = 0.0;
			from = "C";
			to = "K";
	
			convertedValue = temperaturestub.convert(originalValue, from, to);
			System.out.println("\nTemperature Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);

		// results of the Weight converter
			double MultiplierWeight = 0.0;
			originalValue = 10.0;
			convertedValue = 0.0;
			from = "kilogram";
			to = "gram";
	
			convertedValue = weightstub.convert(originalValue, from, to);
			MultiplierWeight = weightstub.getMultiplier(from, to);
			System.out.println("\nWeight Converter");
			System.out.println(originalValue + " " + from + " = " + convertedValue + " " + to);
			System.out.println("Multiplier = " + MultiplierWeight + "\n");
	}
}

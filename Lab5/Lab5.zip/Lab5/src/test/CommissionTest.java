package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import main.Commission;

class CommissionTest {

	Commission commission = new Commission();

	@DisplayName("TS001_TC01-TC016")
	@ParameterizedTest
	@ValueSource(strings = { "-1,-1,-1,-1", "-1,-1,1,-1", "-1,-1,45,-1", "-1,-1,91,-1", "-1,1,-1,-1", "-1,1,1,-1",
			"-1,1,45,-1", "-1,1,91,-1", "-1,40,-1,-1", "-1,40,1,-1", "-1,40,45,-1", "-1,40,91,-1", "-1,81,-1,-1",
			"-1,81,1,-1", "-1,81,45,-1", "-1,81,91,-1" })
	void TS001(String input) {
		String[] text = input.split(",");
		int lock = Integer.parseInt(text[0]);
		int stock = Integer.parseInt(text[1]);
		int barrel = Integer.parseInt(text[2]);
		double expected = Integer.parseInt(text[3]);
		Double total = commission.checkCommission(lock, stock, barrel);
		assertEquals(expected, total);
	}

	@DisplayName("TS002_TC017-TC032")
	@ParameterizedTest
	@ValueSource(strings = { "1,-1,-1,-1", "1,-1,1,-1", "1,-1,45,-1", "1,-1,91,-1", "1,1,-1,-1", "1,1,1,1000",
			"1,1,45,20500", "1,1,91,43500", "1,40,-1,-1", "1,40,1,21900", "1,40,45,43900", "1,40,91,66900",
			"1,81,-1,-1", "1,81,1,46500", "1,81,45,68500", "1,81,91,91500" })
	void TS002(String input) {
		String[] text = input.split(",");
		int lock = Integer.parseInt(text[0]);
		int stock = Integer.parseInt(text[1]);
		int barrel = Integer.parseInt(text[2]);
		double expected = Integer.parseInt(text[3]);
		Double total = commission.checkCommission(lock, stock, barrel);
		assertEquals(expected, total);
	}

	
	@DisplayName("TS003_TC033-TC048")
	@ParameterizedTest
	@ValueSource(strings = { "35,-1,-1,-1", "35,-1,1,-1", "35,-1,45,-1", "35,-1,91,-1", "35,1,-1,-1", "35,1,1,29100",
			"35,1,45,51100", "35,1,91,74100", "35,40,-1,-1", "35,40,1,52500", "35,40,45,74500", "35,40,91,97500",
			"35,81,-1,-1", "35,81,1,77100", "35,81,45,99100", "35,81,91,122100" })
	void TS003(String input) {
		String[] text = input.split(",");
		int lock = Integer.parseInt(text[0]);
		int stock = Integer.parseInt(text[1]);
		int barrel = Integer.parseInt(text[2]);
		double expected = Integer.parseInt(text[3]);
		Double total = commission.checkCommission(lock, stock, barrel);
		assertEquals(expected, total);
	}

	@DisplayName("TS004_TC049-TC064")
	@ParameterizedTest
	@ValueSource(strings = { "71,-1,-1,-1", "71,-1,1,-1", "71,-1,45,-1", "71,-1,91,-1", "71,1,-1,-1", "71,1,1,61500",
			"71,1,45,83500", "71,1,91,106500", "71,40,-1,-1", "71,40,1,84900", "71,40,45,106900", "71,40,91,129900",
			"71,81,-1,-1", "71,81,1,109500", "71,81,45,131500", "71,81,91,154500" })
	void TS004(String input) {
		String[] text = input.split(",");
		int lock = Integer.parseInt(text[0]);
		int stock = Integer.parseInt(text[1]);
		int barrel = Integer.parseInt(text[2]);
		double expected = Integer.parseInt(text[3]);
		Double total = commission.checkCommission(lock, stock, barrel);
		assertEquals(expected, total);
	}

}

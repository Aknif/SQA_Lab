package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import main.ShippingPackage;

class ShippingPackageTest {

	ShippingPackage shippingpackage = new ShippingPackage();
	
	@DisplayName("TC01-TC02")
	@ParameterizedTest
	@ValueSource(strings = { "1,1,5,-1", "1,1,6,1" })
	void TS001(String input) {
		String[] text = input.split(",");
		int small = Integer.parseInt(text[0]);
		int large = Integer.parseInt(text[1]);
		int total = Integer.parseInt(text[2]);
		int expected = Integer.parseInt(text[3]);
		int result = shippingpackage.calculate(small, large, total);
		assertEquals(expected, result);
	}

	@DisplayName("TC03-TC05")
	@ParameterizedTest
	@ValueSource(strings = { "0,1,7,1", "1,0,8,1", "1,1,0,-1" })
	void TS002(String input) {
		String[] text = input.split(",");
		int small = Integer.parseInt(text[0]);
		int large = Integer.parseInt(text[1]);
		int total = Integer.parseInt(text[2]);
		int expected = Integer.parseInt(text[3]);
		int result = shippingpackage.calculate(small, large, total);
		assertEquals(expected, result);
	}
	
	@DisplayName("TC06-TC08")
	@ParameterizedTest
	@ValueSource(strings = { "-1,1,1,-1", "1,-1,1,-1", "1,1,-1,-1" })
	void TS003(String input) {
		String[] text = input.split(",");
		int small = Integer.parseInt(text[0]);
		int large = Integer.parseInt(text[1]);
		int total = Integer.parseInt(text[2]);
		int expected = Integer.parseInt(text[3]);
		int result = shippingpackage.calculate(small, large, total);
		assertEquals(expected, result);
	}
}

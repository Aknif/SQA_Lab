package kku.sqa.lab;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyFirstTest {

	@Test
	void test() {
		assertEquals(5,3+2);
	}

}

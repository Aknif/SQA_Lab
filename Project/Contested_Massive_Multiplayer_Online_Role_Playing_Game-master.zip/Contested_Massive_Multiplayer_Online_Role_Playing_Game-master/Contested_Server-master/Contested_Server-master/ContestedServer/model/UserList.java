package model;

import java.util.ArrayList;

public class UserList {

    public static ArrayList<UserModel> userlist ;
	boolean in = false;
	
	public UserList()
	{
		 
	}

}

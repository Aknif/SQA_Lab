All the DB scripts must be commited to this directory.

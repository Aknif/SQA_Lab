All the server side script must be commited to this directory.

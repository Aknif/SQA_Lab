Contested Massive Multiplayer Online Role Playing Game

Practiced with collaboration of python client and java server with panda3d game engine. 
Implemented heartbeat functionality to update all online player’s moves with other players and different environments.

package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import main.ShiftCipher;

class ShiftCipherTest {
	
	ShiftCipher cipher = new ShiftCipher();

	@DisplayName("TC01")
	@Test
	void TC01_test_shift() {
		String result = cipher.shift("AB", 3);
		assertEquals("DE", result);
	}
	
	@DisplayName("TC02")
	@Test
	void TC02_test_shift() {
		String result = cipher.shift("YZ", 3);
		assertEquals("BC", result);
	}
	
	@DisplayName("TC03")
	@Test
	void TC03_test_shift() {
		String result = cipher.shift("abc", 3);
		assertEquals("invalid", result);
	}
	
	@DisplayName("TC04")
	@Test
	void TC04_test_shift() {
		String result = cipher.shift("@", 3);
		assertEquals("invalid", result);
	}
	
	@DisplayName("TC05")
	@Test
	void TC05_test_shift() {
		String result = cipher.shift("XYZA", -2);
		assertEquals("VWXY", result);
	}

}